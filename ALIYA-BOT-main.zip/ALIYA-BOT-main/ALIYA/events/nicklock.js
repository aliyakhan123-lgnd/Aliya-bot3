const LOCKED_NICKNAME = "🔥 KING 🔥"; // 👈 yahan naam set kar

module.exports = {
  config: {
    name: "nicknamelock",
    eventType: "message"
  },

  async run({ api, event }) {
    const { logMessageType, logMessageData, threadID } = event;

    // nickname change event nahi hai to kuch mat kar
    if (logMessageType !== "log:thread-nickname") return;

    if (!logMessageData || !logMessageData.participant_id) return;

    const userID = logMessageData.participant_id;

    try {
      api.changeNickname(
        LOCKED_NICKNAME,
        threadID,
        userID
      );
    } catch (err) {
      console.log("[NICKNAME LOCK ERROR]:", err.message);
    }
  }
};
