const fs = require("fs");
const path = require("path");

// ===== CONFIG =====
const OWNER_ID = "61581637187236"; // Your UID

// State file
const statePath = path.join(__dirname, "chatlock_state.json");
if (!fs.existsSync(statePath)) {
  fs.writeFileSync(statePath, JSON.stringify({ on: false }));
}

module.exports = {
  config: {
    name: "chatlock",
    eventType: "message"
  },

  async run({ api, event }) {
    const { body, senderID, threadID, messageID } = event;
    if (!body) return;

    const state = JSON.parse(fs.readFileSync(statePath));

    // Bot ko khud ke message ignore kare
    if (senderID === api.getCurrentUserID()) return;

    const msg = body.toLowerCase().trim();

    // Owner commands
    if (senderID === OWNER_ID) {
      if (msg === "chatlock on") {
        state.on = true;
        fs.writeFileSync(statePath, JSON.stringify(state));
        return api.sendMessage(
          "➪ᴼʷⁿᵉʳ Øfficiål ♡Aliya♡\n\n😈 CHATLOCK MODE ON",
          threadID
        );
      }
      if (msg === "chatlock off") {
        state.on = false;
        fs.writeFileSync(statePath, JSON.stringify(state));
        return api.sendMessage(
          "➪ᴼʷⁿᵉʳ Øfficiål ♡Aliya♡\n\n🙂 CHATLOCK MODE OFF",
          threadID
        );
      }
    }

    // Agar ChatLock ON hai
    if (state.on) {
      if (senderID !== OWNER_ID) {
        // Send warning to user
        return api.sendMessage(
          `➪ᴼʷⁿᵉʳ Øfficiål ♡Aliya♡\n\n⚠️ Chat is locked. Only Owner can send messages.\n\nYour message has been ignored.`,
          threadID
        );
      }
    }
  }
};
