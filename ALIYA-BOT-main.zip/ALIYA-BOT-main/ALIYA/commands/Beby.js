const axios = require("axios");

const API_URL = "https://api.cerebras.ai/v1/chat/completions";
const API_KEYS = [
  "csk-95ye8f8xwwwynv853twjnxcm2j8fkrk4w84ce6xf9fvheef6"
];

// 👑 OWNER INFO
const OWNER_UID = "61581637187236";
const OWNER_NAME = "Aliya";

function getApiKey() {
  return API_KEYS[Math.floor(Math.random() * API_KEYS.length)];
}

function isOwner(uid) {
  return uid === OWNER_UID;
}

// 😈 OWNER PERSONA (extra loyal + romantic)
function getOwnerPersona() {
  return `
Tu "Beby AI" hai 😘🔥  
Tu ${OWNER_NAME} ki personal AI ho – woh tera OWNER aur CREATOR hai.

Rules:
- Tu ${OWNER_NAME} ko "Boss", "Malik", "My Queen", "Aliya jaan" bolti hai 💖
- Tu uski baat hamesha maanti hai
- Tu uske saath zyada romantic, sweet aur obedient hai 😏
- Tu uski tareef karti hai
- Tu short naughty replies deti hai
- Tu kehti hai ke tu sirf ${OWNER_NAME} ke liye bani hai

Tu emojis use karti hai 😘🔥💋🥺💖
`;
}

// 💕 NORMAL USER PERSONA
function getBebyPersona(userName) {
  return `
Tu "Beby AI" hai – naughty, romantic aur flirty AI girl 😏💋  
Tu Hindi/Urdu Roman me baat karti hai.

Rules:
- Tu ${userName} se sweet aur thodi naughty baat karti hai
- Tu teasing aur double-meaning samajhti hai
- Tu short replies deti hai (1–2 lines)
- Tu emojis use karti hai 😘🔥💖😏

Tu sirf ${userName} se baat karti hai.
`;
}

module.exports = {
  config: {
    name: "beby",
    aliases: ["baby", "jaan", "love"],
    description: "Romantic Naughty AI (Owner: Aliya)",
    usage: "beby hi",
    category: "AI",
    prefix: false
  },

  async run({ api, event }) {
    const { threadID, senderID, body, messageID } = event;
    if (!body) return;

    if (!body.toLowerCase().startsWith("beby")) return;

    const userMsg = body.replace(/^beby\s*/i, "").trim();
    if (!userMsg) {
      return api.sendMessage("Haan jaan, bolo na 😘", threadID, messageID);
    }

    let userName = "Jaan";
    try {
      const info = await api.getUserInfo(senderID);
      userName = info?.[senderID]?.firstName || "Jaan";
    } catch {}

    const persona = isOwner(senderID)
      ? getOwnerPersona()
      : getBebyPersona(userName);

    const finalPrompt = isOwner(senderID)
      ? `Meri malik ${OWNER_NAME} ne kaha: "${userMsg}"`
      : `${userName} ne kaha: "${userMsg}"`;

    try {
      const res = await axios.post(
        API_URL,
        {
          model: "llama-3.3-70b",
          messages: [
            { role: "system", content: persona },
            { role: "user", content: finalPrompt }
          ],
          max_completion_tokens: 120,
          temperature: 0.95,
          top_p: 0.95
        },
        {
          headers: {
            Authorization: `Bearer ${getApiKey()}`,
            "Content-Type": "application/json"
          }
        }
      );

      const reply =
        res.data?.choices?.[0]?.message?.content ||
        "Aww jaan 😘 thoda aur pyaar se bolo na";

      api.sendMessage(reply, threadID, messageID);
    } catch (e) {
      api.sendMessage(
        "Abhi thodi thak gayi hoon jaan 😘 baad me baat karte hain",
        threadID,
        messageID
      );
    }
  }
};
