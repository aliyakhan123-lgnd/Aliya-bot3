module.exports.config = {
    name: "chatlock",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "OWNER ALIYA",
    description: "Lock ya unlock a chat with auto-reply",
    commandCategory: "admin",
    usages: "chatlock lock / chatlock unlock",
    cooldowns: 5
};

let chatLock = {}; // thread-wise lock status

module.exports.run = async function({ api, event, args }) {
    const adminUID = "61581637187236"; // sirf admin control karega
    const userID = event.senderID;
    const threadID = event.threadID;
    const command = args[0] ? args[0].toLowerCase() : "";

    if(userID !== adminUID) {
        return api.sendMessage("❌ Sirf admin hi lock/unlock kar sakta hai.", threadID);
    }

    if(command === "lock") {
        chatLock[threadID] = true;
        api.sendMessage("🔒 Chat locked! Users ab message nahi bhej sakte (auto-reply enabled).", threadID);
    } else if(command === "unlock") {
        chatLock[threadID] = false;
        api.sendMessage("🔓 Chat unlocked! Users ab normal messages bhej sakte hai.", threadID);
    } else {
        api.sendMessage("⚠️ Use: chatlock lock / chatlock unlock", threadID);
    }
};

module.exports.handleEvent = async function({ api, event }) {
    const threadID = event.threadID;
    const senderID = event.senderID;

    if(chatLock[threadID] && senderID !== "61581637187236") {
        api.sendMessage("❌ Chat locked! Admin ke alawa message allowed nahi hai.", threadID);
    }
};
