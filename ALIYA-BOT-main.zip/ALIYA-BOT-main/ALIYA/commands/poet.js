module.exports = {
  config: {
    name: 'poet',
    aliases: ['poetry', 'shayari'],
    description: 'Random Urdu poetry',
    credits: 'SARDAR RDX',
    usage: 'poet',
    category: 'Fun',
    prefix: false
  },

  handleEvent: async function({ api, event, Users }) {
    const { threadID, messageID, body, senderID } = event;
    
    if (body && body.toLowerCase() === "poet") {
      let name = "Dost";
      try {
        if (Users && Users.getNameUser) {
          name = await Users.getNameUser(senderID);
        } else {
          const info = await api.getUserInfo(senderID);
          name = info[senderID]?.name || "Dost";
        }
      } catch {}

      const poetryLines = [
        "پھر اس کے بعد کیا دیکھے گا کوئی اسے دیکھے کوئی میری نظر سے",
        "تمہیں محبت سے محبت ہونے لگےگی تمہیں محبت سے محبت ہونے لگےگی محبت کو محبت کی نگاہ سے تو دیکھو",
        "اک نام کیا لکھا تیرا ساحل کی ریت پر پھر عمر بھر ہوا سے میری دشمنی رہی",
        "تیرے عشق میں ہو گیا آج رسوا اور پھر کوئی نہیں دل میں ترے سوا",
        "تو نے اچھا ہی کیا ہم سے کنارا کرکے اب نا دیکھیں گے کبھی عشق دوبارہ کرکے",
        "انگلیاں میرے حال پہ اٹھانے والو... عشق کا دوسرا نام فقیری ہے",
        "کیا خبر تھی عشق کے ہاتھوں ایسی حالت تباہ ہوتی ہے",
        "سانس لیتی ہوں دم الجھتا ہے بات کرتی ہوں آہ ہوتی ہے",
        "بڑی ہی برکت ہے تیرے عشق میں جب سے ہوا ہے بڑھتا ہی جارہا ہے",
        "نہیں ہوتا میں تجھ سے جدا بهروسہ رکھ یہ نکاح عشق ہے تیرا حق مہر میری سانسیں ہیں",
        "میں نے اس رات تجھے ہی مانگا خدا سے جس رات لوگ اپنے بخشنے کی دعا مانگ رہے تھے",
        "غیروں میں بٹتی رہی تیری گفتگو کی چاشنی تیری آواز جن کا رزق تھی وہ فاقوں سے مر گئے",
        "گرتے رہے سجدوں میں ہم اپنی حسرتوں کی خاطر عشق خدا میں گرے ہوتے کوئی حسرت ادھوری نہ ہوتی",
        "لگا کر عشق کی بازی سنا ہے روٹھ بیٹھے ہو محبت مار ڈالے گی ابھی تم پھول جیسے ہو",
        "میں خود کو بھی کب میسر ہوں بے سبب ہے تیرا خفا ہونا",
        "کیا کہوں اب عشق کے درد چھپانے کو تم جانتے ہونا مجھے کوئی بہانہ نہیں آتا",
        "خیالِ یار میں بیٹھے ہوئے وہ لوگ ہیں ہم جنہیں زمانہ سمجھتا ہے کوئی کام نہیں",
        "اس قدر اس کی جستجو ہے مجھے جیسے دنیا میں آخری ہو وہ شخص",
        "نہیں ہوتا کسی طبیب سے اس مرض کا علاج عشق لا علاج ہے بس پرہیز کیجیے",
        "اسے چاہا تو محبت کی سمجھ آئی ورنہ ہم عشق کی تکلیف کے بس افسانے سنا کرتے تھے"
      ];

      const selectedLine = poetryLines[Math.floor(Math.random() * poetryLines.length)];

      const message = {
        body: `꧁🍒❤️‍🔥${name}❤️‍🔥🍒꧂\n\n『꧁🍒\n   ${selectedLine} 🍒꧂』\n\n❤️𝕆𝕎ℕ𝔼ℝ : ꧁𝐙𝐚𝐢𝐧𝐢-𝐉𝐮𝐭𝐭꧂🌹`
      };

      return api.sendMessage(message, threadID, messageID);
    }
  },

  async run({ api, event, send, Users }) {
    const { threadID, messageID, senderID } = event;
    
    let name = "Dost";
    try {
      if (Users && Users.getNameUser) {
        name = await Users.getNameUser(senderID);
      } else {
        const info = await api.getUserInfo(senderID);
        name = info[senderID]?.name || "Dost";
      }
    } catch {}

    const poetryLines = [
      "پھر اس کے بعد کیا دیکھے گا کوئی اسے دیکھے کوئی میری نظر سے",
      "تمہیں محبت سے محبت ہونے لگےگی",
      "اک نام کیا لکھا تیرا ساحل کی ریت پر",
      "تیرے عشق میں ہو گیا آج رسوا",
      "تو نے اچھا ہی کیا ہم سے کنارا کرکے",
      "انگلیاں میرے حال پہ اٹھانے والو... عشق کا دوسرا نام فقیری ہے",
      "کیا خبر تھی عشق کے ہاتھوں ایسی حالت تباہ ہوتی ہے",
      "سانس لیتی ہوں دم الجھتا ہے بات کرتی ہوں آہ ہوتی ہے",
      "میں نے اس رات تجھے ہی مانگا خدا سے",
      "نظر ملی آنکھیں جھکی بس اتنی سی بات اور ہم برباد"
    ];

    const selectedLine = poetryLines[Math.floor(Math.random() * poetryLines.length)];

    return send.reply(`꧁🍒❤️‍🔥${name}❤️‍🔥🍒꧂\n\n『꧁🍒\n   ${selectedLine} 🍒꧂』\n\n❤️𝕆𝕎ℕ𝔼ℝ : ꧁𝐙𝐚𝐢𝐧𝐢-𝐉𝐮𝐭𝐭꧂🌹`);
  }
};
