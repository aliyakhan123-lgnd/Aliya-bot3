const fs = require("fs"),
  path = __dirname + "/PREM-BABU/NICK-LOCK.json";

module.exports.config = {
  name: "nicklock",
  version: "1.0.0",
  hasPermssion: 1,
  credits: "PREM BABU",
  description: "GROUP NICKNAME LOCK BOT",
  commandCategory: "GROUP NICK LOCK",
  usages: "NICKLOCK ON/OFF",
  cooldowns: 0
};

module.exports.onLoad = () => {
  if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify({}));
};

module.exports.handleEvent = async function ({ api, event }) {
  const { threadID, logMessageType, logMessageData, isGroup } = event;
  if (!isGroup) return;

  // Sirf nickname change event
  if (logMessageType !== "log:thread-nickname") return;

  let data = JSON.parse(fs.readFileSync(path));

  if (!data[threadID] || data[threadID].status === false) return;

  const userID = logMessageData.participant_id;
  const lockName = data[threadID].nickname;

  if (!lockName) return;

  try {
    api.changeNickname(lockName, threadID, userID);
  } catch (e) {
    console.log("NickLock error:", e.message);
  }
};

module.exports.run = async function ({ api, event, permssion }) {
  const { threadID } = event;
  if (permssion == 0) return;

  let data = JSON.parse(fs.readFileSync(path));

  if (!data[threadID]) {
    data[threadID] = {
      nickname: "🔥 KING 🔥", // 👈 DEFAULT LOCK NAME
      status: true
    };
  } else {
    data[threadID].status = !data[threadID].status;
  }

  fs.writeFileSync(path, JSON.stringify(data, null, 2));

  api.sendMessage(
    `Nickname lock ${data[threadID].status ? "ON 🔒" : "OFF 🔓"}`,
    threadID
  );
};
