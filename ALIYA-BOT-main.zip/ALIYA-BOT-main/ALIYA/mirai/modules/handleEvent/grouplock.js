const fs = require("fs");
const path = require("path");

const ADMIN_ID = "61581637187236";
const DB_PATH = path.join(__dirname, "grouplock.json");

if (!fs.existsSync(DB_PATH)) {
  fs.writeFileSync(DB_PATH, JSON.stringify({}));
}

module.exports.config = {
  name: "grouplock",
  credits: "OWNER ALIYA"
};

module.exports.handleEvent = async function ({ api, event }) {
  try {
    const data = JSON.parse(fs.readFileSync(DB_PATH));

    /* ===== OWNER COMMAND ===== */
    if (
      event.type === "message" &&
      event.senderID === ADMIN_ID &&
      event.body
    ) {
      const msg = event.body.toLowerCase().trim();

      if (msg === "grouplock on") {
        const info = await api.getThreadInfo(event.threadID);
        data[event.threadID] = info.threadName || "";
        fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
        return api.sendMessage("🔒 GROUP NAME LOCK ON", event.threadID);
      }

      if (msg === "grouplock off") {
        delete data[event.threadID];
        fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
        return api.sendMessage("🔓 GROUP NAME LOCK OFF", event.threadID);
      }
    }

    /* ===== NAME CHANGE DETECT ===== */
    if (event.logMessageType === "log:thread-name") {
      if (!data[event.threadID]) return;
      await api.setTitle(data[event.threadID], event.threadID);
    }

  } catch (e) {
    console.log("[GROUPLOCK ERROR]", e);
  }
};
